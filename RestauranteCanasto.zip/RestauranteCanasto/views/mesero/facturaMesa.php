<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factura por Mesa</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/mesero.css?v=<?= time() ?>">
</head>
<body class="dashboard-body">

    <aside class="sidebar">
        <div>
            <div class="logo">
                <img src="<?= BASE_URL ?>public/img/logo.png" alt="Logo">
                <div>
                    <div style="font-size: 18px; font-weight: 700;">Canasto</div>
                    <div style="font-size: 14px; color:#666;">Módulo Mesero</div>
                </div>
            </div>

            <div class="user-info">
                <p style="margin:0; color:#666;"><?= htmlspecialchars($_SESSION['usuario']) ?></p>
                <h2 style="margin:8px 0 0 0;">Mesero</h2>
            </div>

            <div class="menu">
                <div style="font-weight:700; margin-bottom:12px; color:#666;">MENÚ</div>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=index">Dashboard</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos">Productos</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=nuevoPedido">Nuevo pedido</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=verPedidoMesa">Pedidos por mesa</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=facturaMesa" class="active">Facturas</a>
            </div>
        </div>

        <div class="logout-box">
            <a href="<?= BASE_URL ?>index.php?controller=auth&action=logout">Cerrar sesión</a>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div>
                <h1 style="margin:0;">Factura por Mesa</h1>
                <p style="margin:8px 0 0 0; color:#666;">Consulta la factura generada para una mesa.</p>
            </div>
        </div>

        <div class="pedido-layout">
            <section class="pedido-productos">
                <div class="card" style="padding:24px; background:#fff; border-radius:18px; box-shadow:0 4px 12px rgba(0,0,0,0.05);">
                    <form action="<?= BASE_URL ?>index.php" method="GET" style="margin-bottom:24px;">
                        <input type="hidden" name="controller" value="mesero">
                        <input type="hidden" name="action" value="facturaMesa">

                        <label for="mesa" style="display:block; margin-bottom:8px; font-weight:600;">Número de mesa</label>

                        <div style="display:flex; gap:12px; flex-wrap:wrap;">
                            <input
                                type="number"
                                name="mesa"
                                id="mesa"
                                min="1"
                                required
                                value="<?= isset($_GET['mesa']) ? (int)$_GET['mesa'] : '' ?>"
                                style="padding:12px; border:1px solid #ddd; border-radius:10px; min-width:220px;"
                            >

                            <button type="submit" class="btn-add" style="border:none; padding:12px 18px; border-radius:10px; cursor:pointer;">
                                Buscar factura
                            </button>
                        </div>
                    </form>

                    <?php if (!$factura): ?>
                        <p style="color:#666;">Ingresa un número de mesa para ver la factura.</p>
                    <?php else: ?>

                        <?php
                            $detalleFactura = [];

                            if (isset($factura->DETALLE) && is_array($factura->DETALLE)) {
                                $detalleFactura = $factura->DETALLE;
                            } elseif (isset($factura->detalle) && is_array($factura->detalle)) {
                                $detalleFactura = $factura->detalle;
                            }

                            $mesa = $factura->NUMERO_MESA ?? $factura->MESA ?? $factura->mesa ?? '';
                            $idPedido = $factura->ID_PEDIDO ?? $factura->id_pedido ?? '';
                            $subtotal = $factura->SUBTOTAL ?? $factura->subtotal ?? 0;
                            $iva = $factura->IVA ?? $factura->iva ?? 0;
                            $total = $factura->TOTAL ?? $factura->total ?? 0;
                        ?>

                        <div class="carrito-box" style="background:#fff; border-radius:18px; padding:24px; border:1px solid #eee;">
                            <h2 style="margin-top:0; margin-bottom:20px;">Factura</h2>

                            <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:24px;">
                                <div style="background:#f9fafb; padding:16px; border-radius:12px;">
                                    <p style="margin:0; color:#666;">Mesa</p>
                                    <h3 style="margin:8px 0 0 0;"><?= htmlspecialchars($mesa) ?></h3>
                                </div>

                                <div style="background:#f9fafb; padding:16px; border-radius:12px;">
                                    <p style="margin:0; color:#666;">Pedido</p>
                                    <h3 style="margin:8px 0 0 0;">#<?= htmlspecialchars($idPedido) ?></h3>
                                </div>
                            </div>

                            <div style="overflow-x:auto;">
                                <table style="width:100%; border-collapse:collapse;">
                                    <thead>
                                        <tr style="background:#f3f4f6;">
                                            <th style="text-align:left; padding:12px;">Producto</th>
                                            <th style="text-align:left; padding:12px;">Cantidad</th>
                                            <th style="text-align:left; padding:12px;">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($detalleFactura)): ?>
                                            <?php foreach ($detalleFactura as $item): ?>
                                                <?php
                                                    $producto = is_object($item) ? ($item->PRODUCTO ?? $item->producto ?? '') : ($item['PRODUCTO'] ?? $item['producto'] ?? '');
                                                    $cantidad = is_object($item) ? ($item->CANTIDAD ?? $item->cantidad ?? 0) : ($item['CANTIDAD'] ?? $item['cantidad'] ?? 0);
                                                    $subtotalItem = is_object($item) ? ($item->SUBTOTAL ?? $item->subtotal ?? 0) : ($item['SUBTOTAL'] ?? $item['subtotal'] ?? 0);
                                                ?>
                                                <tr style="border-bottom:1px solid #eee;">
                                                    <td style="padding:12px;"><?= htmlspecialchars($producto) ?></td>
                                                    <td style="padding:12px;"><?= (int)$cantidad ?></td>
                                                    <td style="padding:12px;">₡<?= number_format($subtotalItem, 0) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3" style="padding:12px; color:#666;">No hay productos en la factura.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div style="margin-top:24px; display:flex; justify-content:flex-end;">
                                <div style="min-width:280px; background:#f9fafb; padding:20px; border-radius:14px;">
                                    <p style="font-size:20px; margin:8px 0;">
                                        <strong>Subtotal:</strong> ₡<?= number_format($subtotal, 0) ?>
                                    </p>
                                    <p style="font-size:20px; margin:8px 0;">
                                        <strong>IVA:</strong> ₡<?= number_format($iva, 0) ?>
                                    </p>
                                    <p style="font-size:38px; margin:12px 0 0 0; color:#ef4444; font-weight:700;">
                                        Total: ₡<?= number_format($total, 0) ?>
                                    </p>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>

</body>
</html>