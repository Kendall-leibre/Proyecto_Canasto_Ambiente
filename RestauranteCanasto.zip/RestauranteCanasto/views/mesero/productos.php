<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/mesero.css?v=<?= time() ?>">
</head>
<body class="dashboard-body">

    <aside class="sidebar">
        <div>
            <div class="logo">
                <img src="<?= BASE_URL ?>public/img/logo.png" alt="Logo">
                <div>
                    <div style="font-size: 18px; font-weight: 700;">Canasto</div>
                    <div style="font-size: 14px; color:#666;">Módulo Mesero</div>
                </div>
            </div>

            <div class="user-info">
                <p style="margin:0; color:#666;"><?= htmlspecialchars($_SESSION['usuario']) ?></p>
                <h2 style="margin:8px 0 0 0;">Mesero</h2>
            </div>

            <div class="menu">
                <div style="font-weight:700; margin-bottom:12px; color:#666;">MENÚ</div>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=index">Dashboard</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos" class="active">Productos</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=nuevoPedido">Nuevo pedido</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=verPedidoMesa">Pedidos por mesa</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=facturaMesa">Facturas</a>
            </div>
        </div>

        <div class="logout-box">
            <a href="<?= BASE_URL ?>index.php?controller=auth&action=logout">Cerrar sesión</a>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div>
                <h1 style="margin:0;">Productos</h1>
                <p style="margin:8px 0 0 0; color:#666;">Menú disponible para registrar pedidos.</p>
            </div>
        </div>

        <div class="pedido-layout">
            <section class="pedido-productos">
                <div class="cards">
                    <?php while ($p = $productos->fetch_object()): ?>
                        <div class="card producto-card-click" onclick="verProductoMesero(<?= (int)$p->ID_PRODUCTO ?>)">
                            
                            <?php 
                                // 1. Validamos la ruta con la carpeta correcta de productos
                                $rutaMeseroCard = !empty($p->IMAGEN_RUTA) ? "public/img/productos/" . $p->IMAGEN_RUTA : "public/img/productos/default.png";
                            ?>

                            <img src="<?= BASE_URL . $rutaMeseroCard ?>" alt="<?= htmlspecialchars($p->NOMBRE) ?>" style="width: 100%; height: 160px; object-fit: cover; border-radius: 8px;">
                            
                            <h3><?= htmlspecialchars($p->NOMBRE) ?></h3>
                            <p class="price">₡<?= number_format($p->PRECIO, 0) ?></p>
                            <p><?= htmlspecialchars($p->DESCRIPCION) ?></p>

                            <button type="button" class="btn-add" onclick="event.stopPropagation(); verProductoMesero(<?= (int)$p->ID_PRODUCTO ?>)">
                                Ver producto
                            </button>
                        </div>
                    <?php endwhile; ?>
                </div>
            </section>

            <aside class="pedido-carrito">
                <div class="carrito-box">
                    <h2 style="margin-top:0;">Carrito</h2>

                    <?php if (empty($carrito)): ?>
                        <p style="color:#666;">No hay productos agregados.</p>
                    <?php else: ?>
                        <?php $total = 0; ?>
                        <?php foreach ($carrito as $item): ?>
                            <?php $subtotal = $item['precio'] * $item['cantidad']; ?>
                            <?php $total += $subtotal; ?>

                            <div class="carrito-item">
                                <strong><?= htmlspecialchars($item['nombre']) ?></strong>

                                <?php if (!empty($item['opciones'])): ?>
                                    <ul class="carrito-opciones">
                                        <?php foreach ($item['opciones'] as $op): ?>
                                            <li><?= htmlspecialchars($op['nombre']) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>

                                <p style="margin:8px 0;">Cantidad: <?= (int)$item['cantidad'] ?></p>
                                <p style="margin:8px 0;">Subtotal: ₡<?= number_format($subtotal, 0) ?></p>

                                <a
                                    href="<?= BASE_URL ?>index.php?controller=mesero&action=eliminarDelCarrito&id=<?= urlencode($item['key']) ?>"
                                    class="btn-delete"
                                    style="display:inline-block;"
                                >
                                    Quitar
                                </a>
                            </div>
                        <?php endforeach; ?>

                        <h3 class="precio-base">Total: ₡<?= number_format($total, 0) ?></h3>

                        <a href="<?= BASE_URL ?>index.php?controller=mesero&action=nuevoPedido" class="btn-add" style="display:block; text-align:center;">
                            Ir a nuevo pedido
                        </a>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </main>

    <script src="<?= BASE_URL ?>public/js/mesero.js?v=<?= time() ?>"></script>
</body>
</html>