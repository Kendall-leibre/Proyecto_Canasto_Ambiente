<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($producto->getNombre()) ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/mesero.css?v=<?= time() ?>">
</head>
<body class="dashboard-body">

    <aside class="sidebar">
        <div>
            <div class="logo">
                <img src="<?= BASE_URL ?>public/img/logo.png" alt="Logo">
                <div>
                    <div style="font-size: 18px; font-weight: 700;">Canasto</div>
                    <div style="font-size: 14px; color:#666;">Módulo Mesero</div>
                </div>
            </div>

            <div class="user-info">
                <p style="margin:0; color:#666;"><?= htmlspecialchars($_SESSION['usuario']) ?></p>
                <h2 style="margin:8px 0 0 0;">Mesero</h2>
            </div>

            <div class="menu">
                <div style="font-weight:700; margin-bottom:12px; color:#666;">MENÚ</div>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=index">Dashboard</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos" class="active">Productos</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=nuevoPedido">Nuevo pedido</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=verPedidoMesa">Pedidos por mesa</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=facturaMesa">Facturas</a>
            </div>
        </div>

        <div class="logout-box">
            <a href="<?= BASE_URL ?>index.php?controller=auth&action=logout">Cerrar sesión</a>
        </div>
    </aside>

    <main class="main producto-detalle-page">
        <div class="producto-detalle-top">
            
            <?php 
                
                $imgDetalle = $producto->getImagen();
        
                $rutaDetalle = !empty($imgDetalle) ? "public/img/productos/" . $imgDetalle : "public/img/productos/default.png";
            ?>

            <img
                class="producto-detalle-img"
                src="<?= BASE_URL . $rutaDetalle ?>"
                alt="<?= htmlspecialchars($producto->getNombre()) ?>"
                style="width: 100%; max-height: 250px; object-fit: cover; border-radius: 10px;"
            >

            <h1><?= htmlspecialchars($producto->getNombre()) ?></h1>
            <p class="producto-detalle-desc"><?= htmlspecialchars($producto->getDescripcion()) ?></p>
            <p class="producto-detalle-precio" id="precioFinalTexto">₡<?= number_format($producto->getPrecio(), 0) ?></p>
        </div>

        <div class="producto-detalle-box">
            <form method="POST" action="<?= BASE_URL ?>index.php?controller=mesero&action=agregarAlCarrito" id="formAgregarProducto">
                <input type="hidden" name="id_producto" value="<?= (int)$producto->getId() ?>">
                <input type="hidden" name="nombre" value="<?= htmlspecialchars($producto->getNombre()) ?>">
                <input type="hidden" name="precio" id="precioBase" value="<?= (float)$producto->getPrecio() ?>">

                <?php foreach ($modificadores as $mod): ?>
                    <div class="modificador-grupo">
                        <h3><?= htmlspecialchars($mod['nombre']) ?></h3>

                        <?php foreach ($mod['opciones'] as $op): ?>
                            <label class="modificador-opcion">
                                <div>
                                    <input
                                        class="opcion-extra"
                                        type="<?= $mod['tipo'] ?>"
                                        name="opciones[]"
                                        value="<?= (int)$op['id_opcion'] ?>"
                                        data-precio="<?= (float)$op['precio_extra'] ?>"
                                        <?= $mod['tipo'] === 'radio' ? 'data-radio-group="mod_' . (int)$mod['id_modificador'] . '"' : '' ?>
                                    >

                                    <?php if ($mod['tipo'] === 'radio'): ?>
                                        <input type="hidden" name="opciones_nombres[<?= (int)$op['id_opcion'] ?>]" value="<?= htmlspecialchars($op['nombre']) ?>">
                                        <input type="hidden" name="opciones_precios[<?= (int)$op['id_opcion'] ?>]" value="<?= (float)$op['precio_extra'] ?>">
                                    <?php else: ?>
                                        <input type="hidden" name="opciones_nombres[<?= (int)$op['id_opcion'] ?>]" value="<?= htmlspecialchars($op['nombre']) ?>">
                                        <input type="hidden" name="opciones_precios[<?= (int)$op['id_opcion'] ?>]" value="<?= (float)$op['precio_extra'] ?>">
                                    <?php endif; ?>

                                    <span><?= htmlspecialchars($op['nombre']) ?></span>
                                </div>

                                <span class="extra-precio">
                                    <?php if ((float)$op['precio_extra'] > 0): ?>
                                        +₡<?= number_format($op['precio_extra'], 0) ?>
                                    <?php else: ?>
                                        ₡0
                                    <?php endif; ?>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>

                <div class="detalle-actions">
                    <label>Cantidad</label>
                    <input type="number" name="cantidad" value="1" min="1" class="form-control cantidad-input">

                    <div class="detalle-botones">
                        <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos" class="btn btn-dark">
                            Volver
                        </a>

                        <button type="submit" class="btn-add">
                            Agregar al carrito
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>

    <script src="<?= BASE_URL ?>public/js/mesero.js?v=<?= time() ?>"></script>
</body>
</html>