<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos por mesa</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/mesero.css?v=<?= time() ?>">
</head>
<body class="dashboard-body">

    <aside class="sidebar">
        <div>
            <div class="logo">
                <img src="<?= BASE_URL ?>public/img/logo.png" alt="Logo">
                <div>
                    <div style="font-size:18px; font-weight:700;">Canasto</div>
                    <div style="font-size:14px; color:#666;">Módulo Mesero</div>
                </div>
            </div>

            <div class="user-info">
                <p style="margin:0; color:#666;"><?= htmlspecialchars($_SESSION['usuario']) ?></p>
                <h2 style="margin:8px 0 0 0;">Mesero</h2>
            </div>

            <div class="menu">
                <div style="font-weight:700; margin-bottom:12px; color:#666;">MENÚ</div>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=index">Dashboard</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos">Productos</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=nuevoPedido">Nuevo pedido</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=verPedidoMesa" class="active">Pedidos por mesa</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=facturaMesa">Facturas</a>
            </div>
        </div>

        <div class="logout-box">
            <a href="<?= BASE_URL ?>index.php?controller=auth&action=logout">Cerrar sesión</a>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div>
                <h1 style="margin:0;">Pedidos por mesa</h1>
                <p style="margin:8px 0 0 0; color:#666;">Consultá el detalle del pedido.</p>
            </div>
        </div>

        <div class="card" style="padding:24px; background:#fff; border-radius:18px; box-shadow:0 4px 12px rgba(0,0,0,0.05); margin-bottom:24px;">
            <form action="<?= BASE_URL ?>index.php" method="GET">
                <input type="hidden" name="controller" value="mesero">
                <input type="hidden" name="action" value="verPedidoMesa">

                <label for="mesa" style="display:block; margin-bottom:8px; font-weight:600;">Número de mesa</label>
                <input
                    type="number"
                    name="mesa"
                    id="mesa"
                    min="1"
                    required
                    value="<?= isset($_GET['mesa']) ? (int)$_GET['mesa'] : '' ?>"
                    style="width:100%; padding:12px; border:1px solid #ddd; border-radius:10px; margin-bottom:16px;"
                >

                <button type="submit" class="btn-add" style="border:none; padding:12px 18px; border-radius:10px; cursor:pointer;">
                    Buscar
                </button>
            </form>
        </div>

        <?php if ($pedido): ?>
            <div class="card" style="padding:28px; background:#fff; border-radius:18px; box-shadow:0 4px 12px rgba(0,0,0,0.05); max-width:1100px;">
                <h2 style="margin-top:0;">Pedido de la mesa <?= (int)($pedido->NUMERO_MESA ?? 0) ?></h2>

                <p><strong>ID Pedido:</strong> <?= (int)($pedido->ID_PEDIDO ?? 0) ?></p>
                <p><strong>Fecha:</strong> <?= htmlspecialchars($pedido->FECHA_PEDIDO ?? '') ?></p>
                <p><strong>Observaciones:</strong> <?= nl2br(htmlspecialchars($pedido->OBSERVACIONES ?? '')) ?></p>

                <hr style="margin:24px 0; border:none; border-top:1px solid #eee;">

                <h3>Detalle del pedido</h3>

                <?php if (!empty($pedido->detalles)): ?>
                    <?php foreach ($pedido->detalles as $detalle): ?>
                        <div class="carrito-item">
                            <strong><?= htmlspecialchars($detalle->PRODUCTO ?? '') ?></strong>
                            <p style="margin:8px 0;">
                                Cantidad: <?= (int)($detalle->CANTIDAD ?? 0) ?>
                                |
                                Precio: ₡<?= number_format((float)($detalle->PRECIO_UNITARIO ?? 0), 0) ?>
                                |
                                Subtotal: ₡<?= number_format((float)($detalle->SUBTOTAL ?? 0), 0) ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color:#666;">No hay detalles para este pedido.</p>
                <?php endif; ?>
            </div>
        <?php elseif (isset($_GET['mesa'])): ?>
            <div class="card" style="padding:24px; background:#fff; border-radius:18px; box-shadow:0 4px 12px rgba(0,0,0,0.05);">
                <p style="margin:0; color:#666;">No se encontró un pedido para esa mesa.</p>
            </div>
        <?php endif; ?>
    </main>

</body>
</html>