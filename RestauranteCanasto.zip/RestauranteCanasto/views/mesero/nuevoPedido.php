<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Pedido</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/mesero.css?v=<?= time() ?>">
</head>
<body class="dashboard-body">

    <aside class="sidebar">
        <div>
            <div class="logo">
                <img src="<?= BASE_URL ?>public/img/logo.png" alt="Logo">
                <div>
                    <div style="font-size: 18px; font-weight: 700;">Canasto</div>
                    <div style="font-size: 14px; color:#666;">Módulo Mesero</div>
                </div>
            </div>

            <div class="user-info">
                <p style="margin:0; color:#666;"><?= htmlspecialchars($_SESSION['usuario']) ?></p>
                <h2 style="margin:8px 0 0 0;">Mesero</h2>
            </div>

            <div class="menu">
                <div style="font-weight:700; margin-bottom:12px; color:#666;">MENÚ</div>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=index">Dashboard</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos">Productos</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=nuevoPedido" class="active">Nuevo pedido</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=verPedidoMesa">Pedidos por mesa</a>
                <a href="<?= BASE_URL ?>index.php?controller=mesero&action=facturaMesa">Facturas</a>
            </div>
        </div>

        <div class="logout-box">
            <a href="<?= BASE_URL ?>index.php?controller=auth&action=logout">Cerrar sesión</a>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div>
                <h1 style="margin:0;">Nuevo Pedido</h1>
                <p style="margin:8px 0 0 0; color:#666;">Confirma el pedido antes de enviarlo.</p>
            </div>
        </div>

        <div class="pedido-layout">
            <section class="pedido-productos">
                <div class="card" style="padding: 24px; background:#fff; border-radius:18px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
                    <form action="<?= BASE_URL ?>index.php?controller=mesero&action=guardarPedido" method="POST">
                        <div style="margin-bottom:16px;">
                            <label for="numero_mesa" style="display:block; margin-bottom:8px; font-weight:600;">Número de mesa</label>
                            <input
                                type="number"
                                name="numero_mesa"
                                id="numero_mesa"
                                min="1"
                                required
                                class="form-control"
                                style="width:100%; padding:12px; border:1px solid #ddd; border-radius:10px;"
                            >
                        </div>

                        <div style="margin-bottom:16px;">
                            <label for="observaciones" style="display:block; margin-bottom:8px; font-weight:600;">Observaciones</label>
                            <textarea
                                name="observaciones"
                                id="observaciones"
                                rows="5"
                                class="form-control"
                                style="width:100%; padding:12px; border:1px solid #ddd; border-radius:10px;"
                            ></textarea>
                        </div>

                        <?php if (isset($_SESSION['error'])): ?>
                            <div style="background:#fee2e2; color:#991b1b; padding:12px; border-radius:10px; margin-bottom:16px;">
                                <?= htmlspecialchars($_SESSION['error']) ?>
                            </div>
                            <?php unset($_SESSION['error']); ?>
                        <?php endif; ?>

                        <div style="display:flex; gap:12px; flex-wrap:wrap;">
                            <a href="<?= BASE_URL ?>index.php?controller=mesero&action=productos" class="btn btn-dark" style="text-decoration:none; padding:12px 18px; border-radius:10px; background:#111827; color:#fff;">
                                Seguir agregando
                            </a>

                            <button type="submit" class="btn-add" style="border:none; padding:12px 18px; border-radius:10px; cursor:pointer;">
                                Guardar pedido
                            </button>
                        </div>
                    </form>
                </div>
            </section>

            <aside class="pedido-carrito">
                <div class="carrito-box">
                    <h2 style="margin-top:0;">Resumen del pedido</h2>

                    <?php if (empty($carrito)): ?>
                        <p style="color:#666;">No hay productos en el carrito.</p>
                    <?php else: ?>
                        <?php $total = 0; ?>
                        <?php foreach ($carrito as $item): ?>
                            <?php $subtotal = $item['precio'] * $item['cantidad']; ?>
                            <?php $total += $subtotal; ?>

                            <div class="carrito-item">
                                <strong><?= htmlspecialchars($item['nombre']) ?></strong>

                                <?php if (!empty($item['opciones'])): ?>
                                    <ul class="carrito-opciones">
                                        <?php foreach ($item['opciones'] as $op): ?>
                                            <li><?= htmlspecialchars($op['nombre']) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>

                                <p style="margin:8px 0;">Cantidad: <?= (int)$item['cantidad'] ?></p>
                                <p style="margin:8px 0;">Subtotal: ₡<?= number_format($subtotal, 0) ?></p>
                            </div>
                        <?php endforeach; ?>

                        <h3 class="precio-base">Total: ₡<?= number_format($total, 0) ?></h3>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </main>

</body>
</html>