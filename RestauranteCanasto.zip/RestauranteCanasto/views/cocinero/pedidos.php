<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pedidos en cocina</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>public/css/mesero.css?v=<?= time() ?>">
</head>
<body class="dashboard-body">

<main class="main" style="padding:30px;">
    
    <div class="topbar" style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
        <h1 style="margin: 0;">Pedidos en cocina</h1>
        
        <a href="<?= BASE_URL ?>index.php?controller=auth&action=logout" style="text-decoration: none;">
            <button style="background:#ef4444; color:white; border:none; padding:10px 20px; border-radius:10px; font-weight:bold; cursor:pointer;">
                🚪 Cerrar sesión
            </button>
        </a>
    </div>

    <?php if (!empty($pedidos)): ?>

        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:20px;">

            <?php foreach ($pedidos as $pedido): ?>

                <div style="background:#fff; border-radius:18px; padding:24px; box-shadow:0 4px 12px rgba(0,0,0,0.05);">

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <h3 style="margin: 0;">Pedido #<?= $pedido['ID_PEDIDO'] ?></h3>

                        <?php if ($pedido['ID_ESTADO'] == 3): ?>
                            <span style="background:#fef3c7; padding:6px 12px; border-radius:999px;">Pendiente</span>
                        <?php elseif ($pedido['ID_ESTADO'] == 4): ?>
                            <span style="background:#dbeafe; padding:6px 12px; border-radius:999px;">En proceso</span>
                        <?php endif; ?>
                    </div>

                    <p><strong>Mesa:</strong> <?= $pedido['NUMERO_MESA'] ?></p>
                    <p><strong>Fecha:</strong> <?= $pedido['FECHA_PEDIDO'] ?></p>

                    <?php if (!empty($pedido['OBSERVACIONES'])): ?>
                        <div style="background:#f9fafb; padding:12px; border-radius:10px; margin:10px 0;">
                            <?= htmlspecialchars($pedido['OBSERVACIONES']) ?>
                        </div>
                    <?php endif; ?>

                    <h4>Productos</h4>

                    <ul>
                        <?php foreach ($pedido['DETALLE'] as $item): ?>
                            <li><?= $item['PRODUCTO'] ?> x<?= $item['CANTIDAD'] ?></li>
                        <?php endforeach; ?>
                    </ul>

                    <div style="margin-top:15px;">

                        <?php if ($pedido['ID_ESTADO'] == 3): ?>
                            <form method="POST" action="<?= BASE_URL ?>index.php?controller=cocinero&action=cambiarEstado">
                                <input type="hidden" name="id_pedido" value="<?= $pedido['ID_PEDIDO'] ?>">
                                <input type="hidden" name="estado" value="4">
                                <button style="background:#f59e0b; color:white; border:none; padding:10px 16px; border-radius:10px; cursor:pointer; width: 100%;">
                                    Pasar a En proceso
                                </button>
                            </form>

                        <?php elseif ($pedido['ID_ESTADO'] == 4): ?>
                            <form method="POST" action="<?= BASE_URL ?>index.php?controller=cocinero&action=cambiarEstado">
                                <input type="hidden" name="id_pedido" value="<?= $pedido['ID_PEDIDO'] ?>">
                                <input type="hidden" name="estado" value="5">
                                <button style="background:#10b981; color:white; border:none; padding:10px 16px; border-radius:10px; cursor:pointer; width: 100%;">
                                    Marcar Finalizado
                                </button>
                            </form>
                        <?php endif; ?>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div style="background:#fff; padding:24px; border-radius:18px; text-align: center; color: #6b7280;">
            No hay pedidos en cocina en este momento.
        </div>

    <?php endif; ?>

</main>

</body>
</html>