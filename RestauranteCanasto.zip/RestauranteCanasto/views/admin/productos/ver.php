<div class="contenido">

<div class="producto-box">

    <?php 
        // 1. Obtenemos lo que sea que traiga la base de datos
        $img = $producto->getImagen();

        // 2. Validamos: si está vacío o es nulo, ponemos una por defecto de TU carpeta
        if(empty($img)){
            $rutaImagen = "public/img/productos/default.png"; // Asegúrate de tener una imagen llamada default.png aquí
        } else {
            $rutaImagen = "public/img/productos/" . $img;
        }
    ?>

    <img src="<?= BASE_URL . $rutaImagen ?>" alt="<?= $producto->getNombre() ?>">

    <h2><?= $producto->getNombre() ?></h2>

    <p><?= $producto->getDescripcion() ?></p>

    <h3 class="price">
        ₡<span id="total"><?= number_format($producto->getPrecio(), 0) ?></span>
    </h3>

</div>

<form method="POST"
      action="<?= BASE_URL ?>index.php?controller=pedido&action=guardar"
      id="formPedido">

<input type="hidden" id="precioBase" value="<?= $producto->getPrecio() ?>">

<?php if($modificadores && $modificadores->num_rows > 0): ?>

<?php $actual = null; ?>

<?php while($m = $modificadores->fetch_object()): ?>

<?php if($actual != $m->ID_MODIFICADOR): ?>

<?php if($actual !== null): ?>
        </div>
    </div>
<?php endif; ?>

<div class="modificador-box">
    <h4><?= $m->MODIFICADOR ?></h4>
    <div class="opciones">

<?php $actual = $m->ID_MODIFICADOR; ?>

<?php endif; ?>

<label class="opcion">

    <span>
        <?php if($m->MAX_SELECCION == 1): ?>
            <input type="radio" 
                   name="mod_<?= $m->ID_MODIFICADOR ?>" 
                   value="<?= $m->PRECIO_EXTRA ?>" 
                   class="op">
        <?php else: ?>
            <input type="checkbox" 
                   name="mod_<?= $m->ID_MODIFICADOR ?>[]" 
                   value="<?= $m->PRECIO_EXTRA ?>" 
                   class="op">
        <?php endif; ?>

        <?= $m->OPCION ?>
    </span>

    <span class="extra">
        <?= $m->PRECIO_EXTRA > 0 ? "+₡".number_format($m->PRECIO_EXTRA,0) : "" ?>
    </span>

</label>

<?php endwhile; ?>

        </div>
    </div>

<?php else: ?>
<p>No tiene configuraciones</p>
<?php endif; ?>



</form>

</div>