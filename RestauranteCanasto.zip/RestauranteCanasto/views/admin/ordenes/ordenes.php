<link rel="stylesheet" href="<?= BASE_URL ?>public/css/ordenes.css">

<div class="topbar">
    <h2>Órdenes</h2>
    <p>Historial del sistema</p>
</div>

<!-- 🔍 FILTROS -->
<div class="filtros">
    <form method="GET" action="<?= BASE_URL ?>index.php">

        <input type="hidden" name="controller" value="ordenes">
        <input type="hidden" name="action" value="index">

        <input type="text" name="idPedido" placeholder="ID Pedido"
            value="<?= $_GET['idPedido'] ?? '' ?>">

        <input type="text" name="mesa" placeholder="Mesa"
            value="<?= $_GET['mesa'] ?? '' ?>">

        <input type="text" name="nombre" placeholder="Mesero"
            value="<?= $_GET['nombre'] ?? '' ?>">

        <select name="estado">
            <option value="">Estado</option>
            <option value="PENDIENTE">Pendiente</option>
            <option value="EN_PROCESO">En proceso</option>
            <option value="COMPLETADO">Completado</option>
        </select>

        <button type="submit">Buscar</button>

        <a href="<?= BASE_URL ?>index.php?controller=ordenes&action=index" class="btn-clear">
            Limpiar
        </a>

    </form>
</div>

<!--CONTADOR -->
<div class="contador-box">
    <h3>Total de órdenes</h3>
    <span><?= $totalPedidos ?></span>
</div>

<div class="cards-container">

<?php foreach($pedidos as $p): ?>

    <div class="card-orden">

        <h2>Orden #<?= $p['id'] ?></h2>

        <div class="info">
            <p><strong>Mesa:</strong> <?= $p['mesa'] ?></p>
            <p><strong>Mesero:</strong> <?= $p['usuario'] ?></p>
            <p><strong>Fecha:</strong> <?= $p['fecha'] ?></p>
        </div>

        <div class="estado <?= strtolower($p['estado']) ?>">
            <?= $p['estado'] ?>
        </div>

    </div>

<?php endforeach; ?>

</div>