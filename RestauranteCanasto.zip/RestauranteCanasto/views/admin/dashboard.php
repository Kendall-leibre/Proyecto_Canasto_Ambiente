<link rel="stylesheet" href="<?= BASE_URL ?>public/css/dashboard.css">

<div class="topbar">
    <h2>Dashboard</h2>
    <p>Bienvenido al sistema de administración</p>
</div>

<!--CARDS PRINCIPALES -->
<div class="cards">

    <div class="card gradient-blue">
        <h3>Pedidos del día</h3>
        <p><?= $totalPedidos ?? 0 ?></p>
        <span>Hoy</span>
    </div>          

    <div class="card gradient-green">
        <h3>Ventas del día</h3>
        <p>₡<?= number_format($totalVentas ?? 0,0) ?></p>
        <span>Ingresos</span>
    </div>

    <div class="card gradient-purple">
        <h3>Usuarios activos</h3>
        <p><?= $totalUsuarios ?? 0 ?></p>
        <span>Sistema</span>
    </div>

    <div class="card gradient-orange">
        <h3>Productos</h3>
        <p><?= $totalProductos ?? 0 ?></p>
        <span>Menú</span>
    </div>

</div>


<!--ESTADO DEL RESTAURANTE -->
<div class="estado-box">

    <h3>Estado del restaurante</h3>

    <div class="estado-grid">
        <div class="estado-card pendiente">
            <h4>Pendientes</h4>
            <p><?= $pendientes ?? 0 ?></p>
        </div>

        <div class="estado-card proceso">
            <h4>En proceso</h4>
            <p><?= $enProceso ?? 0 ?></p>
        </div>

        <div class="estado-card completado">
            <h4>Completados</h4>
            <p><?= $completados ?? 0 ?></p>
        </div>
    </div>

</div>

<!--ACTIVIDAD RECIENTE -->
<div class="actividad">

    <h3>Últimos pedidos</h3>

    <div class="tabla-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Mesa</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>

            <?php if(!empty($ultimosPedidos)): ?>
                <?php foreach($ultimosPedidos as $p): ?>
                    <tr>
                        <td>#<?= $p['id'] ?></td>
                        <td><?= $p['mesa'] ?></td>
                        <td>
                            <span class="badge <?= strtolower($p['estado']) ?>">
                                <?= $p['estado'] ?>
                            </span>
                        </td>
                        <td><?= $p['fecha'] ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No hay pedidos recientes</td>
                </tr>
            <?php endif; ?>

            </tbody>
        </table>
    </div>

</div>
<!--GRAFICA -->
<div class="grafica-box">
    <h3>Ventas últimos días</h3>
    <canvas id="ventasChart"></canvas>
</div>

<!--CHART.JS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    const labels = <?= json_encode($labels ?? []) ?>;
    const dataVentas = <?= json_encode($dataVentas ?? []) ?>;

    const ctx = document.getElementById('ventasChart');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Ventas ₡',
                data: dataVentas,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true
        }
    });
</script>