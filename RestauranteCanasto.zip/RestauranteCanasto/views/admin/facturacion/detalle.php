<link rel="stylesheet" href="<?= BASE_URL ?>public/css/factura.css">

<div class="topbar">
    <h2>Detalle del Pedido</h2>
</div>

<table>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Unitario</th>
            <th>Subtotal</th>
        </tr>
    </thead>

    <tbody>
    <?php 
    $total = 0;
    while($d = $detalle->fetch_assoc()): 
        $total += $d['SUBTOTAL'];
    ?>
        <tr>
            <td><?= $d['NOMBRE'] ?></td>
            <td><?= $d['CANTIDAD'] ?></td>
            <td>₡<?= $d['PRECIO_UNITARIO'] ?></td>
            <td>₡<?= $d['SUBTOTAL'] ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<h3>Total: ₡<?= $total ?></h3>

<a href="<?= BASE_URL ?>index.php?controller=factura&action=index">
    ← Volver
</a>