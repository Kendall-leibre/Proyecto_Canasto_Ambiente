<link rel="stylesheet" href="<?= BASE_URL ?>public/css/factura.css">

<div class="topbar">
    <h2>Facturación</h2>
    <p>Gestión de facturas</p>
</div>

<?php if(isset($_SESSION['error'])): ?>
    <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<?php if(isset($_SESSION['success'])): ?>
    <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
        <!--filtros -->

<div class="filtros">

    <form method="GET" action="<?= BASE_URL ?>index.php">

        <input type="hidden" name="controller" value="factura">
        <input type="hidden" name="action" value="index">

        <input type="text" name="idPedido" placeholder="ID Pedido"
            value="<?= $_GET['idPedido'] ?? '' ?>">

        <input type="text" name="mesa" placeholder="Mesa"
            value="<?= $_GET['mesa'] ?? '' ?>">

        <input type="text" name="nombre" placeholder="Nombre mesero"
            value="<?= $_GET['nombre'] ?? '' ?>">

        <button type="submit">Buscar</button>

        <a href="<?= BASE_URL ?>index.php?controller=factura&action=index" class="btn-clear">
            Limpiar
        </a>

    </form>

</div>



<div class="cards-container">

<?php foreach($pedidos as $p): ?>

    <?php
        //TRAER DETALLE IGUAL QUE MESERO
        $service = new FacturaService();
        $detalle = $service->obtenerDetalle($p['id']);

        $subtotal = 0;
        $detalleArray = [];

        while($d = $detalle->fetch_assoc()){
            $detalleArray[] = $d;
            $subtotal += $d['SUBTOTAL'];
        }

        $iva = $subtotal * 0.13;
        $total = $subtotal + $iva;
    ?>

    <div class="card-pedido">

        <h2>Factura</h2>

        <div class="info-top">
            <div>
                <p>Mesa</p>
                <h3><?= $p['mesa'] ?></h3>
            </div>

            <div>
                <p>Pedido</p>
                <h3>#<?= $p['id'] ?></h3>
            </div>
        </div>

        <!--DETALLE -->
        <div class="detalle-box">

            <?php if (!empty($detalleArray)): ?>
                <?php foreach ($detalleArray as $item): ?>
                    <div class="item">
                        <span><?= $item['NOMBRE'] ?></span>
                        <span>x<?= $item['CANTIDAD'] ?></span>
                        <span>₡<?= number_format($item['SUBTOTAL'],0) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No hay productos</p>
            <?php endif; ?>

        </div>

        <!--TOTALES -->
        <div class="totales">
            <p><strong>Subtotal:</strong> ₡<?= number_format($subtotal,0) ?></p>
            <p><strong>IVA:</strong> ₡<?= number_format($iva,0) ?></p>
            <h3>Total: ₡<?= number_format($total,0) ?></h3>
        </div>

        <!-- 🎮 FACTURAR -->
        <form method="POST" action="<?= BASE_URL ?>index.php?controller=factura&action=generar">
    <input type="hidden" name="idPedido" value="<?= $p['id'] ?>">

    <select name="metodoPago" required>
        <option value="">Método de pago</option>
        <option value="1">Efectivo</option>
        <option value="2">Tarjeta</option>
    </select>

    <button type="submit">Facturar</button>
</form>

    </div>

<?php endforeach; ?>

</div>