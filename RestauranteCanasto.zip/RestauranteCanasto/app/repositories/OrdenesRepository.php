<?php

class OrdenesRepository {

    private $conn;

    public function __construct() {
        $this->conn = Database::connect();
    }

    public function obtenerOrdenes($filtros = []) {

        $sql = "SELECT 
                    p.ID_PEDIDO,
                    p.NUMERO_MESA,
                    p.FECHA_PEDIDO,
                    e.DESCRIPCION AS ESTADO,
                    u.NOMBRE AS USUARIO
                FROM CANASTO_PEDIDOS_TB p
                INNER JOIN CANASTO_ESTADOS_TB e 
                    ON p.ID_ESTADO = e.ID_ESTADO
                INNER JOIN CANASTO_USUARIOS_TB u 
                    ON p.IDENTIFICACION = u.IDENTIFICACION
                WHERE 1=1";

        $params = [];
        $types = "";

        // 🔍 FILTROS
        if (!empty($filtros['idPedido'])) {
            $sql .= " AND p.ID_PEDIDO = ?";
            $params[] = $filtros['idPedido'];
            $types .= "i";
        }

        if (!empty($filtros['mesa'])) {
            $sql .= " AND p.NUMERO_MESA = ?";
            $params[] = $filtros['mesa'];
            $types .= "i";
        }

        if (!empty($filtros['nombre'])) {
            $sql .= " AND u.NOMBRE LIKE ?";
            $params[] = "%" . $filtros['nombre'] . "%";
            $types .= "s";
        }

        if (!empty($filtros['estado'])) {
            $sql .= " AND e.DESCRIPCION = ?";
            $params[] = $filtros['estado'];
            $types .= "s";
        }

        $sql .= " ORDER BY p.FECHA_PEDIDO DESC";

        $stmt = $this->conn->prepare($sql);

        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();

        return $stmt->get_result();
    }
}