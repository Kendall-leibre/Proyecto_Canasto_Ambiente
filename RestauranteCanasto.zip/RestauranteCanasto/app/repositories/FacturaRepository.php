<?php

class FacturaRepository {

    private $conn;

    public function __construct() {
        $this->conn = Database::connect();
    }

    //calcular factura (solo subtotales)
    public function obtenerPedidoConDetalles($idPedido) {
        $sql = "SELECT SUBTOTAL 
                FROM CANASTO_DETALLE_PEDIDO_TB 
                WHERE ID_PEDIDO = ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $idPedido);
        $stmt->execute();

        return $stmt->get_result();
    }

    //Detalle completo con producto
    public function obtenerDetallePedido($idPedido) {
        $sql = "SELECT 
                    p.NOMBRE,
                    d.CANTIDAD,
                    d.PRECIO_UNITARIO,
                    d.SUBTOTAL
                FROM CANASTO_DETALLE_PEDIDO_TB d
                INNER JOIN CANASTO_PRODUCTOS_TB p 
                    ON d.ID_PRODUCTO = p.ID_PRODUCTO
                WHERE d.ID_PEDIDO = ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $idPedido);
        $stmt->execute();

        return $stmt->get_result();
    }

    public function existeFactura($idPedido) {
        $sql = "SELECT ID_FACTURA 
                FROM CANASTO_FACTURAS_TB 
                WHERE ID_PEDIDO = ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $idPedido);
        $stmt->execute();

        return $stmt->get_result()->num_rows > 0;
    }

    public function crearFactura($idPedido, $subtotal, $total, $metodoPago) {
        $sql = "INSERT INTO CANASTO_FACTURAS_TB
                (ID_PEDIDO, SUBTOTAL, ID_IMPUESTO, TOTAL, ID_METODO_PAGO, ID_ESTADO)
                VALUES (?, ?, 1, ?, ?, 1)";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iddi", $idPedido, $subtotal, $total, $metodoPago);

        return $stmt->execute();
    }

    //FILTROS
    public function obtenerPedidosCompletados($filtros = []) {

        $sql = "SELECT p.ID_PEDIDO, p.NUMERO_MESA, u.NOMBRE
                FROM CANASTO_PEDIDOS_TB p
                INNER JOIN CANASTO_USUARIOS_TB u 
                    ON p.IDENTIFICACION = u.IDENTIFICACION
                WHERE p.ID_ESTADO = 5";

        $params = [];
        $types = "";

        if (!empty($filtros['idPedido'])) {
            $sql .= " AND p.ID_PEDIDO = ?";
            $params[] = $filtros['idPedido'];
            $types .= "i";
        }

        if (!empty($filtros['mesa'])) {
            $sql .= " AND p.NUMERO_MESA = ?";
            $params[] = $filtros['mesa'];
            $types .= "i";
        }

        if (!empty($filtros['nombre'])) {
            $sql .= " AND u.NOMBRE LIKE ?";
            $params[] = "%" . $filtros['nombre'] . "%";
            $types .= "s";
        }

        $stmt = $this->conn->prepare($sql);

        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();

        return $stmt->get_result();
    }
}