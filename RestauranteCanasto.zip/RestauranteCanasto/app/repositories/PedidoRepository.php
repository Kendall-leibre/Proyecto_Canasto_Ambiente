<?php

require_once "config/database.php";

class PedidoRepository
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->connect();
    }

    /* =========================
       CONTAR PEDIDOS
    ========================= */
    public function contar()
    {
        $sql = "SELECT COUNT(*) AS total FROM CANASTO_PEDIDOS_TB";
        $result = $this->db->query($sql);
        $row = $result->fetch_object();
        return $row->total ?? 0;
    }

    /* =========================
       CREAR PEDIDO
    ========================= */
    public function crear($idMesero, $numeroMesa, $observaciones)
    {
        $sql = "INSERT INTO CANASTO_PEDIDOS_TB 
                (IDENTIFICACION, NUMERO_MESA, OBSERVACIONES, ID_ESTADO)
                VALUES (?, ?, ?, 3)";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("iis", $idMesero, $numeroMesa, $observaciones);
        $stmt->execute();

        return $this->db->insert_id;
    }

    /* =========================
       AGREGAR DETALLE AL PEDIDO
    ========================= */
    public function agregarDetalle($idPedido, $idProducto, $cantidad)
    {
        $sqlProducto = "SELECT PRECIO 
                        FROM CANASTO_PRODUCTOS_TB 
                        WHERE ID_PRODUCTO = ?";

        $stmtProducto = $this->db->prepare($sqlProducto);
        $stmtProducto->bind_param("i", $idProducto);
        $stmtProducto->execute();

        $resultProducto = $stmtProducto->get_result();
        $producto = $resultProducto->fetch_object();

        if (!$producto) {
            return false;
        }

        $precioUnitario = (float)$producto->PRECIO;
        $subtotal = $precioUnitario * $cantidad;

        $sql = "INSERT INTO CANASTO_DETALLE_PEDIDO_TB
                (ID_PEDIDO, ID_PRODUCTO, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL, ID_ESTADO)
                VALUES (?, ?, ?, ?, ?, 1)";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("iiidd", $idPedido, $idProducto, $cantidad, $precioUnitario, $subtotal);

        return $stmt->execute();
    }

    /* =========================
       OBTENER TODOS LOS PEDIDOS
    ========================= */
    public function obtenerTodos()
    {
        $sql = "SELECT p.ID_PEDIDO,
                       p.NUMERO_MESA,
                       p.OBSERVACIONES,
                       p.FECHA_PEDIDO,
                       p.ID_ESTADO,
                       u.NOMBRE AS MESERO
                FROM CANASTO_PEDIDOS_TB p
                INNER JOIN CANASTO_USUARIOS_TB u 
                    ON p.IDENTIFICACION = u.IDENTIFICACION
                ORDER BY p.ID_PEDIDO DESC";

        $result = $this->db->query($sql);

        $pedidos = [];
        while ($row = $result->fetch_object()) {
            $pedidos[] = $row;
        }

        return $pedidos;
    }

    /* =========================
       PEDIDOS DE COCINA
    ========================= */
    public function obtenerPedidosCocina()
    {
        $sql = "SELECT p.ID_PEDIDO,
                       p.NUMERO_MESA,
                       p.OBSERVACIONES,
                       p.FECHA_PEDIDO,
                       p.ID_ESTADO
                FROM CANASTO_PEDIDOS_TB p
                WHERE p.ID_ESTADO IN (3, 4)
                ORDER BY p.FECHA_PEDIDO ASC";

        $result = $this->db->query($sql);

        $pedidos = [];
        while ($row = $result->fetch_assoc()) {
            $idPedido = (int)$row['ID_PEDIDO'];

            $sqlDetalle = "SELECT pr.NOMBRE AS PRODUCTO, d.CANTIDAD
                           FROM CANASTO_DETALLE_PEDIDO_TB d
                           INNER JOIN CANASTO_PRODUCTOS_TB pr
                               ON d.ID_PRODUCTO = pr.ID_PRODUCTO
                           WHERE d.ID_PEDIDO = $idPedido";

            $resultDetalle = $this->db->query($sqlDetalle);
            $detalle = [];

            while ($det = $resultDetalle->fetch_assoc()) {
                $detalle[] = $det;
            }

            $row['DETALLE'] = $detalle;
            $pedidos[] = $row;
        }

        return $pedidos;
    }

    /* =========================
       ACTUALIZAR ESTADO PEDIDO
    ========================= */
    public function actualizarEstadoPedido($idPedido, $estado)
    {
        $sql = "UPDATE CANASTO_PEDIDOS_TB
                SET ID_ESTADO = ?
                WHERE ID_PEDIDO = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $estado, $idPedido);

        return $stmt->execute();
    }

    /* =========================
       OBTENER PEDIDO POR MESA
    ========================= */
    public function obtenerPedidoPorMesa($mesa)
    {
        $sqlPedido = "SELECT p.ID_PEDIDO,
                             p.NUMERO_MESA,
                             p.OBSERVACIONES,
                             p.FECHA_PEDIDO,
                             p.ID_ESTADO
                      FROM CANASTO_PEDIDOS_TB p
                      WHERE p.NUMERO_MESA = ?
                      ORDER BY p.ID_PEDIDO DESC
                      LIMIT 1";

        $stmtPedido = $this->db->prepare($sqlPedido);
        $stmtPedido->bind_param("i", $mesa);
        $stmtPedido->execute();

        $resultPedido = $stmtPedido->get_result();
        $pedido = $resultPedido->fetch_object();

        if (!$pedido) {
            return null;
        }

        $sqlDetalle = "SELECT d.ID_PRODUCTO,
                              pr.NOMBRE AS PRODUCTO,
                              d.CANTIDAD,
                              d.PRECIO_UNITARIO,
                              d.SUBTOTAL
                       FROM CANASTO_DETALLE_PEDIDO_TB d
                       INNER JOIN CANASTO_PRODUCTOS_TB pr
                           ON d.ID_PRODUCTO = pr.ID_PRODUCTO
                       WHERE d.ID_PEDIDO = ?";

        $stmtDetalle = $this->db->prepare($sqlDetalle);
        $stmtDetalle->bind_param("i", $pedido->ID_PEDIDO);
        $stmtDetalle->execute();

        $resultDetalle = $stmtDetalle->get_result();

        $detalles = [];
        while ($row = $resultDetalle->fetch_object()) {
            $detalles[] = $row;
        }

        $pedido->detalles = $detalles;

        return $pedido;
    }

    /* =========================
       FACTURA POR MESA
    ========================= */
    public function obtenerFacturaPorMesa($mesa)
    {
        $pedido = $this->obtenerPedidoPorMesa($mesa);

        if (!$pedido) {
            return null;
        }

        $subtotal = 0;
        $detalleFactura = [];

        if (!empty($pedido->detalles)) {
            foreach ($pedido->detalles as $detalle) {
                $subtotal += (float)$detalle->SUBTOTAL;

                $detalleFactura[] = (object)[
                    'PRODUCTO' => $detalle->PRODUCTO,
                    'CANTIDAD' => $detalle->CANTIDAD,
                    'SUBTOTAL' => $detalle->SUBTOTAL
                ];
            }
        }

        $iva = $subtotal * 0.13;
        $total = $subtotal + $iva;

        return (object)[
            'ID_PEDIDO'   => $pedido->ID_PEDIDO,
            'NUMERO_MESA' => $pedido->NUMERO_MESA,
            'DETALLE'     => $detalleFactura,
            'SUBTOTAL'    => $subtotal,
            'IVA'         => $iva,
            'TOTAL'       => $total
        ];
    }
}