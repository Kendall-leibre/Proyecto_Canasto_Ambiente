<?php

require_once "app/services/FacturaService.php";

class FacturaController {

    public function index() {

        $service = new FacturaService();

        // 🔥 RECIBIR FILTROS
        $filtros = [
            "idPedido" => $_GET['idPedido'] ?? null,
            "mesa" => $_GET['mesa'] ?? null,
            "nombre" => $_GET['nombre'] ?? null
        ];

        $pedidosRaw = $service->listarPedidos($filtros);

        // 🔥 Transformar pedidos para mini facturas
        $pedidos = [];

        while($p = $pedidosRaw->fetch_assoc()){

            $factura = $service->obtenerFacturaCompleta($p['ID_PEDIDO']);

            $pedidos[] = [
                "id" => $p['ID_PEDIDO'],
                "mesa" => $p['NUMERO_MESA'],
                "detalle" => $factura['detalle'],
                "subtotal" => $factura['subtotal'],
                "iva" => $factura['iva'],
                "total" => $factura['total']
            ];
        }

        $content = "views/admin/facturacion/facturacion.php";
        require_once "views/admin/layout.php";
    }

   public function generar() {

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $idPedido = $_POST['idPedido'];
        $metodoPago = $_POST['metodoPago'];

        $service = new FacturaService();
        $resultado = $service->generarFactura($idPedido, $metodoPago);

        if (isset($resultado['error'])) {
            $_SESSION['error'] = $resultado['error'];

            header("Location: " . BASE_URL . "index.php?controller=factura&action=index");
            exit;
        }

        //REDIRECT A LA API 
        header("Location: " . BASE_URL . "api/factura.php?id=" . $idPedido);
        exit;
    }
}

    public function detalle() {

        $idPedido = $_GET['id'];

        $service = new FacturaService();
        $detalle = $service->obtenerDetalle($idPedido);

        $content = "views/admin/facturacion/detalle.php";
        require_once "views/admin/layout.php";
    }
}