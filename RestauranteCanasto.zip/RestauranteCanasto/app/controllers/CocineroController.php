<?php

require_once "app/controllers/BaseController.php";
require_once "app/services/PedidoService.php";

class CocineroController extends BaseController
{
    private $pedidoService;

    public function __construct()
    {
        $this->pedidoService = new PedidoService();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    protected function validarCocinero()
    {
        if (!isset($_SESSION['rol']) || (int)$_SESSION['rol'] !== 3) {
            header("Location: " . BASE_URL . "index.php");
            exit;
        }
    }

    public function index()
    {
        $this->validarCocinero();

        $pedidos = $this->pedidoService->obtenerPedidosCocina();
        require_once "views/cocinero/pedidos.php";
    }

    public function cambiarEstado()
    {
        $this->validarCocinero();

        $idPedido = $_POST['id_pedido'] ?? null;
        $estado = $_POST['estado'] ?? null;

        if ($idPedido && $estado) {
            $this->pedidoService->actualizarEstadoPedido($idPedido, $estado);
        }

        header("Location: " . BASE_URL . "index.php?controller=cocinero&action=index");
        exit;
    }
}