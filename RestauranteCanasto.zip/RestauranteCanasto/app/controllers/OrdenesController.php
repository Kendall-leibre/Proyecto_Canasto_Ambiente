<?php

require_once "app/services/OrdenesService.php";

class OrdenesController {

    public function index() {

        $service = new OrdenesService();

        // 🔍 FILTROS
        $filtros = [
            "idPedido" => $_GET['idPedido'] ?? null,
            "mesa" => $_GET['mesa'] ?? null,
            "nombre" => $_GET['nombre'] ?? null,
            "estado" => $_GET['estado'] ?? null
        ];

        $pedidosRaw = $service->listarOrdenes($filtros);

        $pedidos = [];

        while($p = $pedidosRaw->fetch_assoc()){
            $pedidos[] = [
                "id" => $p['ID_PEDIDO'],
                "mesa" => $p['NUMERO_MESA'],
                "fecha" => $p['FECHA_PEDIDO'],
                "estado" => $p['ESTADO'],
                "usuario" => $p['USUARIO']
            ];
        }

        $totalPedidos = count($pedidos);

        $content = "views/admin/ordenes/ordenes.php";
        require_once "views/admin/layout.php";
    }
}