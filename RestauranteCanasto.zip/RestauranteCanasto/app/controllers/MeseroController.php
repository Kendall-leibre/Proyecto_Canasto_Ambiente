<?php

require_once "app/controllers/BaseController.php";
require_once "app/services/MeseroService.php";

class MeseroController extends BaseController
{
    private $meseroService;

    public function __construct()
    {
        $this->meseroService = new MeseroService();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function index()
    {
        $this->validarMesero();
        require_once "views/mesero/dashboard.php";
    }

    public function productos()
    {
        $this->validarMesero();

        $productos = $this->meseroService->obtenerProductos();
        $carrito = $this->meseroService->obtenerCarrito();

        require_once "views/mesero/productos.php";
    }

    public function verProducto()
    {
        $this->validarMesero();

        $id = $_GET['id'] ?? null;
        $data = $this->meseroService->obtenerProductoConModificadores($id);

        if (!$data) {
            header("Location: " . BASE_URL . "index.php?controller=mesero&action=productos");
            exit;
        }

        $producto = $data['producto'];
        $modificadores = $data['modificadores'];
        $carrito = $this->meseroService->obtenerCarrito();

        require_once "views/mesero/verProducto.php";
    }

    public function agregarAlCarrito()
    {
        $this->validarMesero();

        $ok = $this->meseroService->agregarAlCarrito($_POST);

        if (!$ok) {
            header("Location: " . BASE_URL . "index.php?controller=mesero&action=productos");
            exit;
        }

        header("Location: " . BASE_URL . "index.php?controller=mesero&action=productos&msg=pedido_ok");
        exit;
    }

    public function eliminarDelCarrito()
    {
        $this->validarMesero();

        $key = $_GET['id'] ?? null;
        $this->meseroService->eliminarDelCarrito($key);

        header("Location: " . BASE_URL . "index.php?controller=mesero&action=productos");
        exit;
    }

    public function nuevoPedido()
    {
        $this->validarMesero();

        $carrito = $this->meseroService->obtenerCarrito();
        require_once "views/mesero/nuevoPedido.php";
    }

    public function guardarPedido()
    {
        $this->validarMesero();

        $idMesero = $_SESSION['id'] ?? null;
        $numeroMesa = $_POST['numero_mesa'] ?? null;
        $observaciones = trim($_POST['observaciones'] ?? '');

        $resultado = $this->meseroService->guardarPedido($idMesero, $numeroMesa, $observaciones);

        if (empty($resultado['ok'])) {
            $_SESSION['error'] = $resultado['mensaje'] ?? 'No se pudo guardar el pedido';
            header("Location: " . BASE_URL . "index.php?controller=mesero&action=nuevoPedido");
            exit;
        }

        header("Location: " . BASE_URL . "index.php?controller=mesero&action=verPedidoMesa&mesa=" . urlencode($numeroMesa));
        exit;
    }

    public function verPedidoMesa()
    {
        $this->validarMesero();

        $mesa = $_GET['mesa'] ?? null;
        $pedido = null;

        if (!empty($mesa)) {
            $pedido = $this->meseroService->obtenerPedidoPorMesa($mesa);
        }

        require_once "views/mesero/verPedidoMesa.php";
    }

    public function facturaMesa()
    {
        $this->validarMesero();

        $mesa = $_GET['mesa'] ?? null;
        $factura = null;

        if (!empty($mesa)) {
            $factura = $this->meseroService->obtenerFacturaPorMesa($mesa);
        }

        require_once "views/mesero/facturaMesa.php";
    }
}