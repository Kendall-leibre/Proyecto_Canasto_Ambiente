<?php

require_once "app/controllers/BaseController.php";
require_once "app/services/PedidoService.php";

class PedidoController extends BaseController {

    private $pedidoService;

    public function __construct(){
        $this->pedidoService = new PedidoService();
    }

    public function index(){
        $this->validarSesion();

        $conn = Database::connect();

        // CARDS
        $totalPedidos = $this->pedidoService->contarPedidos();

        $res = $conn->query("SELECT SUM(TOTAL) as total FROM CANASTO_FACTURAS_TB WHERE DATE(FECHA_FACTURA)=CURDATE()");
        $totalVentas = $res->fetch_assoc()['total'] ?? 0;

        $res = $conn->query("SELECT COUNT(*) as total FROM CANASTO_USUARIOS_TB WHERE ID_ESTADO=1");
        $totalUsuarios = $res->fetch_assoc()['total'] ?? 0;

        $res = $conn->query("SELECT COUNT(*) as total FROM CANASTO_PRODUCTOS_TB WHERE ID_ESTADO=1");
        $totalProductos = $res->fetch_assoc()['total'] ?? 0;

        //ESTADOS
        $res = $conn->query("SELECT COUNT(*) total FROM CANASTO_PEDIDOS_TB WHERE ID_ESTADO=3");
        $pendientes = $res->fetch_assoc()['total'] ?? 0;

        $res = $conn->query("SELECT COUNT(*) total FROM CANASTO_PEDIDOS_TB WHERE ID_ESTADO=4");
        $enProceso = $res->fetch_assoc()['total'] ?? 0;

        $res = $conn->query("SELECT COUNT(*) total FROM CANASTO_PEDIDOS_TB WHERE ID_ESTADO=5");
        $completados = $res->fetch_assoc()['total'] ?? 0;

        //ÚLTIMOS PEDIDOS
        $sql = "SELECT 
                    ID_PEDIDO,
                    NUMERO_MESA,
                    FECHA_PEDIDO,
                    ID_ESTADO
                FROM CANASTO_PEDIDOS_TB
                ORDER BY FECHA_PEDIDO DESC
                LIMIT 5";

        $result = $conn->query($sql);

        $ultimosPedidos = [];

        while($row = $result->fetch_assoc()){
            $estadoTexto = '';

            if($row['ID_ESTADO'] == 3) $estadoTexto = 'PENDIENTE';
            if($row['ID_ESTADO'] == 4) $estadoTexto = 'EN_PROCESO';
            if($row['ID_ESTADO'] == 5) $estadoTexto = 'COMPLETADO';

            $ultimosPedidos[] = [
                "id" => $row['ID_PEDIDO'],
                "mesa" => $row['NUMERO_MESA'],
                "estado" => $estadoTexto,
                "fecha" => $row['FECHA_PEDIDO']
            ];
        }

        //GRAFICA (ventas últimos 7 días)
        $sql = "SELECT 
                    DATE(FECHA_FACTURA) as fecha,
                    SUM(TOTAL) as total
                FROM CANASTO_FACTURAS_TB
                GROUP BY DATE(FECHA_FACTURA)
                ORDER BY fecha ASC
                LIMIT 7";

        $result = $conn->query($sql);

        $labels = [];
        $dataVentas = [];

        while($row = $result->fetch_assoc()){
            $labels[] = $row['fecha'];
            $dataVentas[] = $row['total'];
        }

        $content = "views/admin/dashboard.php";
        require_once "views/admin/layout.php";
    }
}