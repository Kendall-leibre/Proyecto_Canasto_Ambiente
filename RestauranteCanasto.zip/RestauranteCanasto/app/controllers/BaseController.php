<?php

class BaseController
{
    protected function iniciarSesionSiNoExiste()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    protected function validarSesion()
    {
        $this->iniciarSesionSiNoExiste();

        if (!isset($_SESSION['usuario'])) {
            header("Location: " . BASE_URL . "index.php");
            exit;
        }
    }

    protected function esAdmin()
    {
        $this->iniciarSesionSiNoExiste();
        return isset($_SESSION['rol']) && (int)$_SESSION['rol'] === 1;
    }

    protected function esMesero()
    {
        $this->iniciarSesionSiNoExiste();
        return isset($_SESSION['rol']) && (int)$_SESSION['rol'] === 2;
    }

    protected function esCocinero()
    {
        $this->iniciarSesionSiNoExiste();
        return isset($_SESSION['rol']) && (int)$_SESSION['rol'] === 3;
    }

    protected function validarAdmin()
    {
        $this->validarSesion();

        if (!$this->esAdmin()) {
            header("Location: " . BASE_URL . "index.php");
            exit;
        }
    }

    protected function validarMesero()
    {
        $this->validarSesion();

        if (!$this->esMesero()) {
            header("Location: " . BASE_URL . "index.php");
            exit;
        }
    }

    protected function validarCocinero()
    {
        $this->validarSesion();

        if (!$this->esCocinero()) {
            header("Location: " . BASE_URL . "index.php");
            exit;
        }
    }
}