<?php

require_once "app/repositories/OrdenesRepository.php";

class OrdenesService {

    private $repo;

    public function __construct() {
        $this->repo = new OrdenesRepository();
    }

    public function listarOrdenes($filtros = []) {
        return $this->repo->obtenerOrdenes($filtros);
    }
}