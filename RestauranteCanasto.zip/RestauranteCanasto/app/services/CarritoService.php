<?php

class CarritoService
{
    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['carrito'])) {
            $_SESSION['carrito'] = [];
        }
    }

    public function obtenerCarrito()
    {
        return $_SESSION['carrito'] ?? [];
    }

    public function agregarProducto($postData)
    {
        $idProducto = $postData['id_producto'] ?? null;
        $nombre = $postData['nombre'] ?? '';
        $precioBase = (float)($postData['precio'] ?? 0);
        $cantidad = (int)($postData['cantidad'] ?? 1);

        $opcionesSeleccionadas = $postData['opciones'] ?? [];
        $nombresOpciones = $postData['opciones_nombres'] ?? [];
        $preciosOpciones = $postData['opciones_precios'] ?? [];

        if (!$idProducto || $cantidad <= 0) {
            return false;
        }

        $extras = 0;
        $detalleOpciones = [];

        if (is_array($opcionesSeleccionadas)) {
            foreach ($opcionesSeleccionadas as $idOpcion) {
                $idOpcion = (string)$idOpcion;

                $nombreOpcion = $nombresOpciones[$idOpcion] ?? '';
                $precioExtra = (float)($preciosOpciones[$idOpcion] ?? 0);

                $extras += $precioExtra;

                $detalleOpciones[] = [
                    'id_opcion' => $idOpcion,
                    'nombre' => $nombreOpcion,
                    'precio_extra' => $precioExtra
                ];
            }
        }

        $precioFinal = $precioBase + $extras;
        $key = $idProducto . '_' . md5(json_encode($detalleOpciones));

        if (isset($_SESSION['carrito'][$key])) {
            $_SESSION['carrito'][$key]['cantidad'] += $cantidad;
        } else {
            $_SESSION['carrito'][$key] = [
                'key' => $key,
                'id_producto' => $idProducto,
                'nombre' => $nombre,
                'precio_base' => $precioBase,
                'precio' => $precioFinal,
                'cantidad' => $cantidad,
                'opciones' => $detalleOpciones
            ];
        }

        return true;
    }

    public function eliminarProducto($key)
    {
        if ($key && isset($_SESSION['carrito'][$key])) {
            unset($_SESSION['carrito'][$key]);
            return true;
        }

        return false;
    }

    public function limpiar()
    {
        $_SESSION['carrito'] = [];
    }

    public function estaVacio()
    {
        return empty($_SESSION['carrito']);
    }

    public function prepararResumenPedido($observaciones = '')
    {
        $carrito = $this->obtenerCarrito();
        $productos = [];
        $cantidades = [];
        $observacionesFinales = trim($observaciones ?? '');

        foreach ($carrito as $item) {
            $productos[] = $item['id_producto'];

            if (!isset($cantidades[$item['id_producto']])) {
                $cantidades[$item['id_producto']] = 0;
            }

            $cantidades[$item['id_producto']] += (int)$item['cantidad'];

            if (!empty($item['opciones'])) {
                $nombres = array_map(function ($op) {
                    return $op['nombre'];
                }, $item['opciones']);

                $observacionesFinales .= "\n" . $item['nombre'] . ": " . implode(", ", $nombres);
            }
        }

        return [
            'productos' => $productos,
            'cantidades' => $cantidades,
            'observaciones' => trim($observacionesFinales)
        ];
    }
}