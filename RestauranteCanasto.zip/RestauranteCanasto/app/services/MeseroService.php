<?php

require_once "app/services/ProductoService.php";
require_once "app/services/PedidoService.php";
require_once "app/services/CarritoService.php";

class MeseroService
{
    private $productoService;
    private $pedidoService;
    private $carritoService;

    public function __construct()
    {
        $this->productoService = new ProductoService();
        $this->pedidoService = new PedidoService();
        $this->carritoService = new CarritoService();
    }

    public function obtenerProductos()
    {
        return $this->productoService->obtenerTodos();
    }

    public function obtenerCarrito()
    {
        return $this->carritoService->obtenerCarrito();
    }

    public function obtenerProductoConModificadores($idProducto)
    {
        if (!$idProducto) {
            return null;
        }

        $producto = $this->productoService->obtenerPorId($idProducto);

        if (!$producto) {
            return null;
        }

        $resultado = $this->productoService->obtenerModificadoresConOpciones($idProducto);
        $modificadores = [];

        if ($resultado) {
            while ($row = $resultado->fetch_object()) {
                $idMod = $row->ID_MODIFICADOR;

                if (!isset($modificadores[$idMod])) {
                    $modificadores[$idMod] = [
                        'id_modificador' => $row->ID_MODIFICADOR,
                        'nombre' => $row->MODIFICADOR,
                        'min' => $row->MIN_SELECCION,
                        'max' => $row->MAX_SELECCION,
                        'tipo' => ((int)$row->MIN_SELECCION === 1 && (int)$row->MAX_SELECCION === 1) ? 'radio' : 'checkbox',
                        'opciones' => []
                    ];
                }

                if (!empty($row->ID_OPCION)) {
                    $modificadores[$idMod]['opciones'][] = [
                        'id_opcion' => $row->ID_OPCION,
                        'nombre' => $row->OPCION,
                        'precio_extra' => $row->PRECIO_EXTRA
                    ];
                }
            }
        }

        return [
            'producto' => $producto,
            'modificadores' => $modificadores
        ];
    }

    public function agregarAlCarrito($postData)
    {
        return $this->carritoService->agregarProducto($postData);
    }

    public function eliminarDelCarrito($key)
    {
        return $this->carritoService->eliminarProducto($key);
    }

    public function guardarPedido($idMesero, $numeroMesa, $observaciones)
    {
        if (empty($numeroMesa)) {
            return [
                'ok' => false,
                'mensaje' => 'Debe indicar la mesa'
            ];
        }

        if ($this->carritoService->estaVacio()) {
            return [
                'ok' => false,
                'mensaje' => 'Debe agregar al menos un producto'
            ];
        }

        $resumen = $this->carritoService->prepararResumenPedido($observaciones);

        $resultado = $this->pedidoService->crearPedidoCompleto(
            $idMesero,
            $numeroMesa,
            $resumen['observaciones'],
            $resumen['productos'],
            $resumen['cantidades']
        );

        if (!empty($resultado['ok'])) {
            $this->carritoService->limpiar();
        }

        return $resultado;
    }

    public function obtenerPedidoPorMesa($mesa)
    {
        return $this->pedidoService->obtenerPedidoPorMesa($mesa);
    }

    public function obtenerFacturaPorMesa($mesa)
    {
        return $this->pedidoService->obtenerFacturaPorMesa($mesa);
    }
}