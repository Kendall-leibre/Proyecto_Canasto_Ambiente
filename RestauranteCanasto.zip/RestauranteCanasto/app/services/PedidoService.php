<?php

require_once "app/repositories/PedidoRepository.php";

class PedidoService
{
    private $repo;

    public function __construct()
    {
        $this->repo = new PedidoRepository();
    }

    /* =========================
       ADMIN
    ========================= */

    public function contarPedidos()
    {
        return $this->repo->contar();
    }

    public function obtenerTodos()
    {
        return $this->repo->obtenerTodos();
    }

    public function crearPedido($usuario, $observaciones = '')
    {
        if (empty($usuario)) {
            $usuario = 1;
        }

        return $this->repo->crear($usuario, $observaciones);
    }

    /* =========================
       COCINERO
    ========================= */

    public function obtenerPedidosCocina()
    {
        return $this->repo->obtenerPedidosCocina();
    }

    public function actualizarEstadoPedido($idPedido, $estado)
    {
        if (empty($idPedido) || empty($estado)) {
            return false;
        }

        return $this->repo->actualizarEstadoPedido($idPedido, $estado);
    }

    /* =========================
       MESERO
    ========================= */

    public function crearPedidoCompleto($idMesero, $numeroMesa, $observaciones, $productos, $cantidades)
    {
        if (empty($numeroMesa) || empty($productos)) {
            return [
                "ok" => false,
                "mensaje" => "Debe indicar la mesa y seleccionar al menos un producto"
            ];
        }

        $idPedido = $this->repo->crear($idMesero, $numeroMesa, $observaciones);

        if (!$idPedido) {
            return [
                "ok" => false,
                "mensaje" => "Error al crear el pedido"
            ];
        }

        foreach ($productos as $idProducto) {
            $cantidad = isset($cantidades[$idProducto]) ? (int)$cantidades[$idProducto] : 1;

            if ($cantidad > 0) {
                $this->repo->agregarDetalle($idPedido, $idProducto, $cantidad);
            }
        }

        return [
            "ok" => true,
            "id_pedido" => $idPedido
        ];
    }

    public function obtenerPedidoPorMesa($mesa)
    {
        if (empty($mesa)) {
            return null;
        }

        return $this->repo->obtenerPedidoPorMesa($mesa);
    }

    public function obtenerFacturaPorMesa($mesa)
    {
        if (empty($mesa)) {
            return null;
        }

        return $this->repo->obtenerFacturaPorMesa($mesa);
    }
}