<?php

require_once "app/repositories/FacturaRepository.php";

class FacturaService {

    private $repo;

    public function __construct() {
        $this->repo = new FacturaRepository();
    }

    //RECIBE FILTROS
    public function listarPedidos($filtros = []) {
        return $this->repo->obtenerPedidosCompletados($filtros);
    }

    public function generarFactura($idPedido, $metodoPago) {

        if ($this->repo->existeFactura($idPedido)) {
            return ["error" => "Este pedido ya tiene factura"];
        }

        $detalles = $this->repo->obtenerPedidoConDetalles($idPedido);

        $subtotal = 0;

        while ($row = $detalles->fetch_assoc()) {
            $subtotal += $row['SUBTOTAL'];
        }

        $iva = $subtotal * 0.13;
        $total = $subtotal + $iva;

        $ok = $this->repo->crearFactura($idPedido, $subtotal, $total, $metodoPago);

        if ($ok) {
            return ["success" => "Factura generada"];
        }

        return ["error" => "Error al generar factura"];
    }

    public function obtenerDetalle($idPedido) {
        return $this->repo->obtenerDetallePedido($idPedido);
    }

    //factura completa para cards
    public function obtenerFacturaCompleta($idPedido) {

        $detalle = $this->repo->obtenerDetallePedido($idPedido);

        $subtotal = 0;

        while($row = $detalle->fetch_assoc()){
            $subtotal += $row['SUBTOTAL'];
        }

        $iva = $subtotal * 0.13;
        $total = $subtotal + $iva;

        // 🔁 volver a consultar
        $detalle = $this->repo->obtenerDetallePedido($idPedido);

        return [
            "detalle" => $detalle,
            "subtotal" => $subtotal,
            "iva" => $iva,
            "total" => $total
        ];
    }
}