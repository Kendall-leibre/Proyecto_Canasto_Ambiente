<?php

require_once "../config/database.php";

$conn = Database::connect();

$idPedido = $_GET['id'] ?? null;

if(!$idPedido){
    die("ID inválido");
}

//TRAER INFO GENERAL DEL PEDIDO
$sqlPedido = "SELECT 
                p.ID_PEDIDO,
                p.NUMERO_MESA,
                f.ID_METODO_PAGO,
                mp.NOMBRE AS METODO_PAGO
            FROM CANASTO_PEDIDOS_TB p
            LEFT JOIN CANASTO_FACTURAS_TB f 
                ON p.ID_PEDIDO = f.ID_PEDIDO
            LEFT JOIN CANASTO_METODOS_PAGO_TB mp 
                ON f.ID_METODO_PAGO = mp.ID_METODO_PAGO
            WHERE p.ID_PEDIDO = ?";

$stmt = $conn->prepare($sqlPedido);
$stmt->bind_param("i", $idPedido);
$stmt->execute();

$pedido = $stmt->get_result()->fetch_assoc();

if(!$pedido){
    die("Pedido no encontrado");
}

//TRAER DETALLE
$sqlDetalle = "SELECT 
                    pr.NOMBRE,
                    d.CANTIDAD,
                    d.SUBTOTAL
               FROM CANASTO_DETALLE_PEDIDO_TB d
               INNER JOIN CANASTO_PRODUCTOS_TB pr 
                    ON d.ID_PRODUCTO = pr.ID_PRODUCTO
               WHERE d.ID_PEDIDO = ?";

$stmt = $conn->prepare($sqlDetalle);
$stmt->bind_param("i", $idPedido);
$stmt->execute();

$result = $stmt->get_result();

$items = [];
$subtotal = 0;

while($row = $result->fetch_assoc()){
    $items[] = $row;
    $subtotal += $row['SUBTOTAL'];
}

$iva = $subtotal * 0.13;
$total = $subtotal + $iva;

//NOMBRE ARCHIVO
$nombreArchivo = "Factura_Pedido_" . $idPedido . ".txt";

//HEADERS DESCARGA
header('Content-Type: text/plain');
header("Content-Disposition: attachment; filename=$nombreArchivo");

// CONTENIDO TXT
echo "=====================================\n";
echo "        RESTAURANTE CANASTO\n";
echo "=====================================\n";
echo "Pedido: #" . $pedido['ID_PEDIDO'] . "\n";
echo "Mesa: " . $pedido['NUMERO_MESA'] . "\n";
echo "Fecha: " . date("Y-m-d H:i:s") . "\n";
echo "Metodo de pago: " . ($pedido['METODO_PAGO'] ?? 'N/A') . "\n";
echo "=====================================\n";

foreach($items as $i){
    echo str_pad($i['NOMBRE'], 20);
    echo "x" . $i['CANTIDAD'] . " ";
    echo "₡" . number_format($i['SUBTOTAL'],0) . "\n";
}

echo "=====================================\n";
echo "Subtotal: ₡" . number_format($subtotal,0) . "\n";
echo "IVA (13%): ₡" . number_format($iva,0) . "\n";
echo "TOTAL: ₡" . number_format($total,0) . "\n";
echo "=====================================\n";
echo "Gracias por su compra 🙌\n";