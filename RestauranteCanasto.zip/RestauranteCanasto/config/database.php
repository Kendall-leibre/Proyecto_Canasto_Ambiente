<?php

class Database {

    public static function connect(){
        $host = "127.0.0.1";
        $user = "root";
        $pass = "kendall2405";
        $db   = "restaurante_canasto";

        $conn = new mysqli($host, $user, $pass, $db);

        if($conn->connect_error){
            die("Error de conexión: " . $conn->connect_error);
        }

        return $conn;
    }
}