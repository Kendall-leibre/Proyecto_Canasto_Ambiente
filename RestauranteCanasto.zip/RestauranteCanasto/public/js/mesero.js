function verProductoMesero(id) {
    window.location.href = "index.php?controller=mesero&action=verProducto&id=" + id;
}

function initCalculoProductoMesero() {
    const precioBaseInput = document.getElementById("precioBase");
    const precioFinalTexto = document.getElementById("precioFinalTexto");
    const opciones = document.querySelectorAll(".opcion-extra");

    if (!precioBaseInput || !precioFinalTexto || opciones.length === 0) return;

    function calcularTotal() {
        let total = parseFloat(precioBaseInput.value || 0);

        opciones.forEach(op => {
            if (op.checked) {
                total += parseFloat(op.dataset.precio || 0);
            }
        });

        precioFinalTexto.textContent = "₡" + total.toLocaleString("es-CR");
    }

    opciones.forEach(op => {
        op.addEventListener("change", calcularTotal);
    });

    calcularTotal();
}

function initMensajeMesero() {
    const params = new URLSearchParams(window.location.search);
    const msg = params.get("msg");

    if (!msg) return;

    if (msg === "pedido_ok" && typeof Swal !== "undefined") {
        Swal.fire({
            icon: "success",
            title: "Producto agregado al carrito"
        });
    }
}

document.addEventListener("DOMContentLoaded", function () {
    initCalculoProductoMesero();
    initMensajeMesero();
});