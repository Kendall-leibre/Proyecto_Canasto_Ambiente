/* =========================
   EDITAR USUARIO
========================= */
function editarUsuario(id) {
    window.location.href = "index.php?controller=usuario&action=editar&id=" + id;
}

/* =========================
   CAMBIAR ESTADO (Activo/Inactivo)
========================= */
function cambiarEstado(id, estado) {
    Swal.fire({
        title: '¿Cambiar estado?',
        text: "¿Deseas modificar el acceso de este usuario?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, cambiar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "index.php?controller=usuario&action=cambiarEstado&id=" + id + "&estado=" + estado;
        }
    });
}

/* =========================
   CAMBIAR ROL
========================= */
function cambiarRol(id, rol) {
    Swal.fire({
        title: '¿Cambiar rol?',
        text: "¿Estás seguro de asignar un nuevo rol a este usuario?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, cambiar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "index.php?controller=usuario&action=cambiarRol&id=" + id + "&rol=" + rol;
        } else {
            // Si cancela, recargamos para que el select vuelva a su valor original visualmente
            location.reload();
        }
    });
}

/* =========================
    VALIDAR FORMULARIO
========================= */
function validarFormulario() {
    let nombre = document.querySelector("[name='nombre']").value;
    let correo = document.querySelector("[name='correo']").value;
    let rol = document.querySelector("[name='rol']").value;

    if (nombre.trim() === "" || correo.trim() === "" || rol === "") {
        Swal.fire("Campos incompletos", "Por favor llena los campos obligatorios", "error");
        return false;
    }
    return true;
}

/* =========================
    FILTRAR USUARIOS (Buscador en tiempo real)
========================= */
function initFiltroUsuarios() {
    const buscador = document.getElementById("buscador");
    const filtroRol = document.getElementById("filtroRol");
    const filtroEstado = document.getElementById("filtroEstado");
    const filas = document.querySelectorAll(".tabla-usuarios tbody tr");

    if (!buscador || !filtroRol || !filtroEstado) return;

    function filtrar() {
        let texto = buscador.value.toLowerCase().trim();
        let rol = filtroRol.value;
        let estado = filtroEstado.value;

        filas.forEach(f => {
            let id = f.dataset.id;
            let nombre = f.dataset.nombre;
            let rolFila = f.dataset.rol;
            let estadoFila = f.dataset.estado;

            let okTexto = id.includes(texto) || nombre.includes(texto);
            let okRol = (rol === "" || rol === rolFila);
            let okEstado = (estado === "" || estado === estadoFila);

            f.style.display = (okTexto && okRol && okEstado) ? "" : "none";
        });
    }

    buscador.addEventListener("input", filtrar);
    filtroRol.addEventListener("change", filtrar);
    filtroEstado.addEventListener("change", filtrar);
}

/* =========================
    VERIFICAR MENSAJES DE URL (Notificaciones)
========================= */
function verificarMensajes() {
    const urlParams = new URLSearchParams(window.location.search);
    const msg = urlParams.get('msg');

    if (msg) {
        let config = { confirmButtonColor: '#28a745' };

        if (msg === 'creado') {
            config.title = '¡Excelente!';
            config.text = 'El usuario se ha creado correctamente';
            config.icon = 'success';
        } else if (msg === 'actualizado') {
            config.title = '¡Actualizado!';
            config.text = 'Los datos del usuario se guardaron bien';
            config.icon = 'success';
        } else if (msg === 'error') {
            config.title = 'Error';
            config.text = 'No se pudo completar la acción';
            config.icon = 'error';
        }

        if (config.title) {
            Swal.fire(config).then(() => {
                // Limpia la URL sin recargar para estética
                const url = new URL(window.location);
                url.searchParams.delete('msg');
                window.history.replaceState({}, document.title, url);
            });
        }
    }
}

/* =========================
    INICIALIZADOR
========================= */
document.addEventListener("DOMContentLoaded", function() {
    initFiltroUsuarios();
    verificarMensajes();
});