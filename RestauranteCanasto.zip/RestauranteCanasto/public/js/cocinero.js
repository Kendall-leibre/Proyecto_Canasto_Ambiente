document.addEventListener("DOMContentLoaded", function () {
    console.log("Módulo cocinero cargado");
});